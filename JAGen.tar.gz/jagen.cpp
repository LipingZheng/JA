#include "jagen.h"
#include "satcheck.h"
#include "cmd_line_options.h"

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <deque>
#include <stack>
#include <iterator>
#include<time.h>

using namespace std;

extern Options *program_options;

string prefixToInfix(string prefix);

void JA::generatePreagenda()
{
    int numOfOperators;
    set < int > anum;
    set <int>::iterator it;
    int atomnum;
    bool lastIsNeg;
    
    int sizeOfPreagenda = 5;    // can be got as a parameter
    if(program_options->isSet("-p"))
	sizeOfPreagenda = program_options->getInt("-p");
    
    int totalNumOfAtom = 10;     // can be got as a parameter
    if(program_options->isSet("-a"))
	totalNumOfAtom = program_options->getInt("-a");
    
    int maxNumOperators = 5 ;    // can be got as a parameter
    if(program_options->isSet("-o"))
	maxNumOperators = program_options->getInt("-o");
    
    double probconj = 0.33;       // can be got as a parameter
    if(program_options->isSet("-conj"))
	probconj = program_options->getDouble("-conj");
    
    double probdisj = 0.33;// can be got as a parameter
    if(program_options->isSet("-disj"))
	probdisj = program_options->getDouble("-disj");
    probdisj = probconj+probdisj;
    
    //generate formula in preagenda;
    for(int i=1;i <= sizeOfPreagenda;i++)
    {
	stringstream  fprefix;
	string finfix;
	lastIsNeg = false;
	
	//rand number of operators with maxNumOperators;
	numOfOperators = rand()% maxNumOperators + 1;
	
	//generate first operators;
	int un_op_so_far = 0;
	int bin_op_so_far = 0;
	double dice = (double) rand()/(double)RAND_MAX;
	if(dice < probconj)
	{
	    fprefix << " &";
	    bin_op_so_far++;
	    lastIsNeg = false;
	}else{	 
	    if(dice < probdisj){
		fprefix << " |";
		bin_op_so_far++;
		lastIsNeg = false;
	    }else{
		fprefix << " ~";
		un_op_so_far++;
		lastIsNeg = true;
	    }
	}
	
	int operators_to_go = numOfOperators -1;
	int atoms_so_far = 0;
	
	while(operators_to_go != 0 || ((bin_op_so_far > 0) && (atoms_so_far < bin_op_so_far )))
	{
	    int rounded = (double) operators_to_go * probdisj;
	    
	    if(( atoms_so_far == bin_op_so_far) || (rand() % (operators_to_go + (bin_op_so_far - atoms_so_far) + rounded )) < operators_to_go )
	    {
		dice = (double) rand() /(double)RAND_MAX;
		if(dice < probconj)
		{
		    fprefix << " &";
		    bin_op_so_far++;
		    lastIsNeg = false;
		}else{	 
		    if(dice < probdisj){
			fprefix << " |";
			bin_op_so_far++;
			lastIsNeg = false;
		    }else{
			if (!lastIsNeg)
			{
			    fprefix << " ~";
			    lastIsNeg = true;
			}
			un_op_so_far++;
		    }
		}
		operators_to_go--;
	    }else{
		
		//decide which operand
		// to make sure one operand only occurd onetime in a formula
		atomnum=(rand()% totalNumOfAtom) + 1 ;
		it = anum.find(atomnum);		
		while( it != anum.end())
		{
		    atomnum=(rand()% totalNumOfAtom) + 1 ;
		    it = anum.find(atomnum);  
		}
		
		fprefix << " p"<<atomnum;
		anum.insert(atomnum);		
		atoms_so_far++;
	    }
	    
	}
	//append last operand 
	// to make sure one operand only occurd onetime in a formula
	atomnum=(rand()% totalNumOfAtom) + 1 ;
	it = anum.find(atomnum);
	
	while( it != anum.end())
	{
	    atomnum=(rand()% totalNumOfAtom) + 1 ;
	    it = anum.find(atomnum);  
	}
	
	fprefix << " p" << atomnum << endl;
	
	// check
//	cout << "prefix :" << fprefix.str() ;//<< std::endl;
	
	//get infix formula as a string;
	finfix = prefixToInfix(fprefix.str());
	
	// check
//	cout << "infix : "<<finfix << std::endl;
	preagenda.push_back(finfix);
	
	anum.clear();
    }
    

}
void JA::generateProfile()
{
    int itemp, val;
    vector <string> v_Str;
    string tStr;
    int sizeOfProfile = 10;// can be got as a parameter, default 10;
    
    if(program_options->isSet("-j"))
	sizeOfProfile = program_options->getInt("-j");
       
    int psize=preagenda.size();

    if(program_options->isSet("-c")){ // complete Judgment sets
	for ( int j = 0; j < sizeOfProfile; j++ ){
	    Judgment jm;
	    jm.resize(psize);
	    for ( int i = 0; i < psize; i++){
		jm[i] = '*' ;
	    }
	    for ( int i = 0; i < psize; i++)
	    {
		itemp = rand() % psize;
		while ( jm [itemp] != '*'){
        		itemp = rand() % psize;
		}
		val = rand() % 2;
		switch ( val ){		 
		    case 0:{
			tStr = '~' + preagenda[itemp];
			v_Str.push_back(tStr);
			if (satcheck(v_Str)){
			     jm[itemp]='0';			    
			}else{
			     jm[itemp]='1';
			     v_Str.pop_back();
			     v_Str.push_back(preagenda[itemp]);
			}
			break;			
		    }
		    case 1: {
			v_Str.push_back(preagenda[itemp]);
			if( satcheck(v_Str)){
			    jm[itemp]='1';
			}else{
			    jm[itemp]='0';
			    v_Str.pop_back();
			    tStr = '~' + preagenda[itemp];
			    v_Str.push_back(tStr);
			}
			break;
		    }		    
		} // end of switch
	    } // end of for
	    
	    v_Str.clear();
	    profile.push_back(jm);	    
	}	
    }else{  // incomplete Judgment sets
	for ( int j = 0; j < sizeOfProfile; j++){
	    bool uSat=false;
	    Judgment jm;
	    jm.resize(psize);
	    for( int i = 0; i < psize; i++){
		jm[i] = '*';
	    }
	    for( int i = 0; i< psize; i++){
		itemp = rand() % psize;
		while ( jm [itemp] != '*'){
		    itemp = rand() % psize;
		}
		val = rand() % 3;

		switch (val){
		    case 0:{
			tStr = '~' + preagenda[itemp];
			v_Str.push_back(tStr);
			if(satcheck(v_Str)){
			    jm[itemp] = '0';
			}else{ 
			    jm[itemp]= '1';
			    v_Str.pop_back();
			    v_Str.push_back(preagenda[itemp]);
			}
			break;
		    }
		    case 1:{
			v_Str.push_back(preagenda[itemp]);
			if(satcheck(v_Str)){
			    jm[itemp] = '1';
			}else{
			    jm[itemp]= '0';
			    v_Str.pop_back();
			    tStr = '~' + preagenda[itemp];
			    v_Str.push_back(tStr);
			}
			break;
		    }
		    case 2:{
			break;
		    }
		    default:;
		}//end of switch
		
	    }// end of for
	    v_Str.clear();
	    profile.push_back(jm);	    
	}
	
    }

#if 0

    if(program_options->isSet("-c"))
    {
	for(int j = 0; j< sizeOfProfile;)
	{	   
	    Judgment jm;  
	    for(int i=0;i<psize;i++)
	    {
		itemp = rand() % 2;
		switch ( itemp)
		{
		    cout<< j << endl;
		    case 0:{
			jm.push_back( '0');
			tStr='~'+preagenda[i];
//			cout<< tStr<<"\t ";
			v_Str.push_back(tStr); 
			break;
		    }
		    case 1: {
			jm.push_back( '1'); 
			v_Str.push_back(preagenda[i]);
//			cout<<preagenda[i]<<"\t ";
			break;
		    }
		    default: ;
		}		
	    }
	    
//	    cout<< "j = "<< j<<endl;	    
	    if(satcheck(v_Str)) {
		profile.push_back(jm);
		j++;
	    }
	    v_Str.clear();
	    if(program_options->getInt("-p")>15){
		clock_t start;
		start = clock();
		while(clock()-start < 2000); //sleep (4000)
	    }else if(program_options->getInt("-p")>10){
		clock_t start;
		start = clock();
		while(clock()-start < 1000); //sleep(2000)
	    }	    
	}
    }else{
	for(int j = 0; j<sizeOfProfile; )
	{	   
	    Judgment jm;  
	    for(int i=0;i<psize;i++)
	    {
		itemp = rand() % 5;
		switch(itemp)
		{
		    case 0: 
		    case 1:{
			jm.push_back( '0');
			tStr='~'+preagenda[i];
			v_Str.push_back(tStr); 
			break;
		    }
		    case 2: 
		    case 3:{
			jm.push_back( '1');
			v_Str.push_back(preagenda[i]);
			break;
		    }
		    case 4: jm.push_back( '*'); break;
		    default:;
		}
	    }
	    
	    if(satcheck(v_Str)) {		
		profile.push_back(jm);
		j++;
	    }
	    v_Str.clear();
	    if(program_options->getInt("-p")>15){
		clock_t start;
		start = clock();
		while(clock()-start < 4000);
	    }else if(program_options->getInt("-p")>10){
		clock_t start;
		start = clock();
		while(clock()-start < 2000);
	    }
	}
	
    }
#endif

}

void JA::WriteFile()
{
    ofstream op;
    string filename;
    filename=program_options->getString("-f");
    op.open(filename.c_str(),ios::out);
    
    int size;
    size=preagenda.size();
    for(int i = 0;i < size;i++)
    {
	op<<preagenda[i]<<endl;
    }
    op<<"#"<<endl;
    
    int psize;
    psize=profile.size();
    
    for(int i =0; i < psize; i++)
    {
	for(int j = 0;j < size;j++)
	{
	    op << profile[i][j]<<" ";
	}
	op<<endl;
    }
    
    op<< '#' << endl;
    op.close();

}

string prefixToInfix(string fprefix)
{
    istringstream iss(fprefix);
    deque <string> deque_;
    copy(istream_iterator<string>(iss),istream_iterator<string>(),back_inserter<deque<string> >(deque_));
    
    stack<string> stack_;
    while(!deque_.empty()){
	string token = deque_.back();
	deque_.pop_back();
	if((token == "&" ) || (token == "|")){
	    stringstream output;
	    output << "(" << stack_.top() <<" " << token << " ";
	    stack_.pop();
	    output << stack_.top() << ")";
	    stack_.pop();
	    stack_.push(output.str());
	}else{
	    if ( token == "~") {
		stringstream output;
		output << token << stack_.top();
		stack_.pop();
		stack_.push(output.str());
	    }else{
		stack_.push(token);
	    }
	}
	
    }
    return stack_.top();

}

