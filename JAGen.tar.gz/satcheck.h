#ifndef _SATCHECK_H
#define _SATCHECK_H

#include <map>
#include <vector>
#include <string>

extern "C" {
    #include "picosat.h"
}

using namespace std;

typedef vector <long>   clause_cnf;
typedef vector <clause_cnf>  formula_cnf;
static int gID;



struct SubStr
{
    vector <string> vstr;
    char op; 
    SubStr() {op='#';};
};

SubStr* getSubStr(string sStr);
int EXT( int id, formula_cnf &f_cnf,string str);
void formulaToCNF( int id,formula_cnf &f_cnf, string srcstr);
bool satcheck(vector <string>& vStr); 

#endif