program: JAGen 
related options:
-h                 display usage instructions
-c                  recomand judgment set only complete
-p      ARG     the size of preagenda [default:5]
-a      ARG     the total number of atoms [default:6]
-o      ARG     the max number of operators [default:5]
-j      ARG     the number of judgment sets [default:10]
-conj   ARG     the provability of conjunctions [default:0.33]
-disj   ARG     the provability of disjunctions [default:0.33]
(note: ARG means that the commad needs an argument)

commad :  ./jagen <filename> [options] 
create in scnu 2015 by zlp

