#ifndef  CMD_LINE_OPTIONS_H
#define  CMD_LINE_OPTIONS_H

#include <map>
#include <string>
#include <set>


using namespace std;

struct option{   
    string argument;
};

class Options {
private:
    map < string, option*> map_options;
    set < string > set_options;
    void addOptions(string opt, string argument);
public:
    Options();
    bool isSet(string opt);
    int getInt(string opt); 
    double getDouble(string opt);
    string getString(string opt);
    bool parseOptions(int argc, char*argv[]);
    void print_helpmessage();
    int numOfParseOptions();
};


#endif