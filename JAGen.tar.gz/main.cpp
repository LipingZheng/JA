/////////////////////////////////////////////////////////
//main.cpp
//
//created by LipingZheng on 19/11/2014
//
/////////////////////////////////

#include "cmd_line_options.h"
#include <iostream>
#include <sstream> 
//#include <iomanip>
#include <algorithm>
#include "jagen.h"
#include <time.h>


Options *program_options = NULL;


int main(int argc, char *argv[]) {
    
    srand(time(NULL));
    program_options = new Options();  
    // if there was an error, the user requested help or the user did not provide arguments,
    //we show the usage instructions
    if (!program_options->parseOptions(argc, argv) || program_options->isSet("-h") 
	|| program_options->numOfParseOptions()== 0 ){
	program_options->print_helpmessage();
    }else  //otherwise, generate an instance;
    {
	JA ja;
	ja.generatePreagenda();
	ja.generateProfile();
	ja.WriteFile();
    }
}

