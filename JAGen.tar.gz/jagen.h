#ifndef JAGEN_H
#define JAGEN_H

#include <vector>
#include <string>

using namespace std;
typedef  vector < char > Judgment;

struct M_P_Member{
    M_P_Member() : f_n(-1), num(0), isNegated(false) {};
    int f_n;
    int num;
    bool isNegated;   
};

class JA{      
private:
    vector < string > preagenda;
    vector < Judgment > profile;
    
public: 
    JA(){};
    ~JA(){};
    void generatePreagenda();
    void generateProfile();
    void WriteFile(); // output instance to the file;
};

#endif