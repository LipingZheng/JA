#include "cmd_line_options.h"

#include <iostream>
#include <map>
#include <set>
#include <string>
#include <sstream>

using namespace std;

Options::Options()
{
    string setopt[]={"-h","-c","-p","-a","-o","-j","-conj","-disj"};
    set_options.insert(setopt,setopt+8);
}


void Options::addOptions(string opt, string argument)
{
    option *new_option=new option();
    new_option->argument = argument;
    map_options.insert(pair<string,option*>(opt,new_option));
}

bool Options::isSet(string opt)
{
    map<string,option*>::iterator it;
    it=map_options.find(opt);
    if(it != map_options.end()){
	//option has been set;
	return true;
    }
    return false;
}

int Options::getInt(string opt)
{
    int result = 0;
    map <string, option*>::iterator it = map_options.find(opt);
    if(it != map_options.end()) {
	istringstream ss ((it->second)->argument);
	ss >> result;
    }
    return result;
}

double Options::getDouble(string opt)
{
    double result=0;
    map <string, option*>::iterator it = map_options.find(opt);
    if(it != map_options.end()) {
	istringstream ss ((it->second)->argument);
	ss >> result;
    }
    return result;
}

string Options::getString(string opt)
{
    string result = "";
    map<string, option*>::iterator it = map_options.find(opt);
    if(it != map_options.end()) {
	istringstream ss ((it->second)->argument);
	ss >> result;
    }
    return result;
}


bool Options::parseOptions(int argc, char*argv[])
{
    
    set <string>::iterator it;
    string sarg,sopt;
        
    if(argc > 1 ){
	string filename = argv[1];
	it=set_options.find(filename);
	if(it!=set_options.end()){
	    //it is a options, not filename;
	    if(*it != "-h") {
		cout<< "error:  filename is required first"<<endl;
	    }
	    return false;
	}
	addOptions("-f", argv[1]);	
    }else{
	cout<< "error:  filename is required"<<endl;
	return false;	
    }
    
    for(int i = 2; i < argc; i++){
	it=set_options.find(argv[i]);
	if(it!=set_options.end()){
	    // option is legal
	    if(*it=="-h"||*it=="-c"){
		sarg="";
	    } else{
		  sarg=argv[++i];
	    }
	    sopt=*it;	  
	    addOptions(sopt,sarg);
	}else{
	    cout<<"error:  invalid commad " <<argv[i]<<endl;
	    return false;
	}		
    }
    if(isSet("-p") && getInt("-p") <= 0){
	cout<< "error: the option -p requires a non-negative ARG\n";
	return false;
    }else if( isSet("-a") && getInt("-a") <= 0){
	cout<< "error: the option -a requires a non-negative ARG\n"; 
	return false;
    }else if( isSet("-o") && getInt("-o") <= 0){
	cout<< "error: the option -o requires a non-negative ARG\n"; 
	return false;
    }else if( isSet("-j") && getInt("-j") <=0 ){
	cout<< "error: the option -j requires a non-negative ARG\n"; 
	return false;	
    }else if (isSet("-conj") && (getDouble("-conj") < 0 || getDouble("-conj") > 1)){
	cout<< "error: the option -conj requires an ARG in [0,1]\n"; 
	return false;	
    }else if ( isSet ("-disj") && (getDouble("-disj") < 0 || getDouble("-disj") >1 )){
	cout<< "error: the option -disj requires an ARG in [0,1]\n"; 
	return false;	
    }
    
    return true;   
}

void Options::print_helpmessage()
{
    cout<<"\nprogram: JAGen "<<endl;
    cout<<"related options:\n";
    cout<< "-h                 display usage instructions\n"<<
    "-c                  recomand judgment set only complete\n"<<
    "-p      ARG     the size of preagenda [default:5]\n"<<
    "-a      ARG     the total number of atoms [default:6]\n"<<
    "-o      ARG     the max number of operators [default:5]\n"<<
    "-j      ARG     the number of judgment sets [default:10]\n"<<
    "-conj   ARG     the provability of conjunctions [default:0.33]\n"<<
    "-disj   ARG     the provability of disjunctions [default:0.33]\n";
    
    cout<<"(note: ARG means that the commad needs an argument)"<<endl<<endl;
    cout<<"commad :  ./jagen <filename> [options] "<<endl;
    cout<< "create in scnu 2015 by zlp"<<endl;  
}

int Options::numOfParseOptions()
{
    return map_options.size();
}

