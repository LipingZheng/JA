#include "satcheck.h"
#include <stdio.h>
#include <iostream>
#include <vector>

map <string, int> mapAtom; 

SubStr* getSubStr(string sStr)
{
    string str="";
    string Str;
    string srcStr;
    char fchar;
    SubStr* substr = new SubStr();
    int i,j, count=0;
    int opCount =0;
    int strno=0;
    int size = sStr.size();
    
    //remove the spaces
    for( i = 0 ; i<size; i++){
	if(sStr[i]!=' '){
	    Str.push_back(sStr[i]);
	}
    }  
    fchar=Str[0];
    
    if(fchar=='('){ 
	size=Str.size();
	count=1;
	for(j = 1;j < size-1; j++){
	    if(Str[j]=='(')
		count++;
	    if(Str[j]==')')
		count--;
	    if(count==0)
		break;
	}
	if(j==size-1){
	    // remove the outermost parentheses
	    for(i=1; i<size-1;i++){  
		srcStr.push_back(Str[i]);
	    }
	}else{
	    srcStr=Str;    
	}
    }else{
	srcStr=Str;
    }
    
 //   cout<< "srcStr "<< srcStr<<endl;   
    count=0;
    size=srcStr.size();
    for(i = 0; i < size; i++){
	switch(srcStr[i]){
	    case '~':  {
		if(i != 0)
		    str.push_back(srcStr[i]);
		opCount++;
		break;
	    }
	    case '(':  {	
		str.push_back(srcStr[i]);
		count++; 
		break;
	    }
	    case ')':  { 
		str.push_back(srcStr[i]);
		count--; 
		if(count==0) {		 		    
		    if(strno==0 && i==(size-1) && srcStr[0]=='~') {
			substr->vstr.push_back(str);
//			cout<<str<<endl;
			substr->op='~';
			str="";
		    }else {
			if (strno==0 && srcStr[0] == '~')
			    str='~'+str;
			substr->vstr.push_back(str);
//			cout<<str<<endl;
			str="";	
		    } 
		    strno++;
		}
		break;			
	    }
	    case '|': 
	    case '&': {
		opCount++;
		if(count == 0 && srcStr[i-1] != ')'){
		    if (strno==0 && srcStr[0] == '~')
			str='~'+str;
//		    cout<<str<<endl;
		    strno++;
		    substr->vstr.push_back(str);
		    str="";
		    substr->op=srcStr[i];
		}else if (count == 0){
		    substr->op=srcStr[i];
		}else{
		    str.push_back(srcStr[i]);
		}
		break;
	    }
	    default:
		str.push_back(srcStr[i]);	   
	}
	
    }
    if(str!="") {
	if(srcStr[0]=='~' && opCount == 1)
	    str= '~' + str;
	substr->vstr.push_back(str);
//	cout<<str<<endl;
    }
    return substr;
}

int EXT( int id, formula_cnf &f_cnf,string str)
{
    clause_cnf c_cnf;
    
    //to get the substr of str;
    SubStr* substr = getSubStr(str);
   

    switch(substr->op){
	case '~': {
	    long lit1,lit2;
	    lit1 = id;
	    lit2 = ++gID;
	    int j = EXT(lit2,f_cnf,substr->vstr[0]);
	    if(j != 0){ // if substr is a literal; 		
		lit2 = j;		
	    }	    
	    c_cnf.push_back(lit1);
	    c_cnf.push_back(lit2);
	    f_cnf.push_back(c_cnf);
	    c_cnf.clear();
	    c_cnf.push_back(lit1 *(-1));
	    c_cnf.push_back(lit2 *(-1));
	    f_cnf.push_back(c_cnf);	    
	    break;
	}
	case '|':{
	    long lit1,lit2,lit3;
	    int j,k;
	    lit1 = id;
	    lit2 = ++gID;
	    lit3 = ++gID;
	    j = EXT(lit2,f_cnf,substr->vstr[0]);
	    if(j != 0){ // if substr is a literal; 		
		lit2 = j;		
	    }	
	    k = EXT(lit3,f_cnf,substr->vstr[1]);
	    if(k != 0){ // if substr is a literal; 		
		lit3 = k;		
	    }	  
	    c_cnf.push_back(lit1);
	    c_cnf.push_back(lit2 *(-1));
	    f_cnf.push_back(c_cnf);
	    c_cnf.clear();
	    c_cnf.push_back(lit1);
	    c_cnf.push_back(lit3 *(-1));
	    f_cnf.push_back(c_cnf);
	    c_cnf. clear();
	    c_cnf.push_back(lit1 *(-1));
	    c_cnf.push_back(lit2);
	    c_cnf.push_back(lit3);
	    f_cnf.push_back(c_cnf);	    
	    
	    break;
	}	    
	case '&':{
	    long lit1,lit2,lit3;
	    lit1 = id;
	    lit2 = ++gID;
	    lit3 = ++gID;
	    int j,k ;
	    j = EXT(lit2,f_cnf,substr->vstr[0]);
	    if(j!=0){ // if substr is a literal; 		
		lit2 = j;		
	    }	
	    k = EXT(lit3,f_cnf,substr->vstr[1]);
	    if(k!=0){ // if substr is a literal; 		
		lit3 = k;		
	    }	
	    c_cnf.push_back(lit1*(-1));
	    c_cnf.push_back(lit2);
	    f_cnf.push_back(c_cnf);
	    c_cnf.clear();
	    c_cnf.push_back(lit1 * (-1));
	    c_cnf.push_back(lit3);
	    f_cnf.push_back(c_cnf);
	    c_cnf.clear();
	    c_cnf.push_back(lit1);
	    c_cnf.push_back(lit2 *(-1));
	    c_cnf.push_back(lit3 *(-1));
	    f_cnf.push_back(c_cnf);	    
	    
	    break;
	}	    
	case '#': {
	    long lit1;//,lit2;			     
	    if(substr->vstr[0][0] == '~') { // if is a negation atom
		string str;	   
		for(int j = 1; j < substr -> vstr[0].size(); j++){
		    str.push_back(substr->vstr[0][j]);
		}
		lit1=(mapAtom.find(str)->second) * (-1);
	    }else{
		lit1= mapAtom.find(substr->vstr[0])->second;
	    }
	    return lit1;
	}
}    
return 0;   
}

void formulaToCNF( int id,formula_cnf &f_cnf, string srcstr)
{   
    clause_cnf c_cnf;
    long lit;
    lit = id ;
    int j = EXT(id,f_cnf,srcstr);
    if (j != 0){
	lit = j; 
    }
    c_cnf.push_back(lit);
    f_cnf.push_back(c_cnf); 
}


bool satcheck(vector <string>& vStr) 
{   
    formula_cnf f_cnf;
    string atom;
    int i,j, id = 1;
    bool lastIsAtom = false;
    map < string, int>::iterator  iter ;
//    cout<< "debug vStr "<<vStr.size()<<endl;
    for(j= 0; j< vStr.size();j++){	
	for( i = 0; i < vStr[j].size(); i++){
	    switch(vStr[j][i]){
		case '~': 
		case '|':
		case '&':
		case '(':
		case ')':{ 
		    if(lastIsAtom) { 
			iter = mapAtom.find(atom);
			if(iter == mapAtom.end()){
			    //not find;
			    mapAtom.insert(pair<string, int> (atom, id));
			    id++;
			}
			atom = "";
			lastIsAtom = false;		    
		    } 
		    break; 
		}
		case ' ': break;
		default:  atom.push_back(vStr[j][i]); lastIsAtom = true;
	    }	
	}
      
	if(lastIsAtom) {
	    iter = mapAtom.find(atom);
	    if(iter == mapAtom.end()){
		mapAtom.insert(pair<string, int> (atom, id));
		id++;
	    }
	}
	    
    }
 //   cout<< " before to cnf id = " << id << endl;
    
    // initialize the golbal variables gID;
    gID = id;
    
    for(i=0; i < vStr.size(); i++){
	formulaToCNF(gID,f_cnf,vStr[i]);
    }
    PicoSAT *ps= picosat_init ();
    int res;
    
    for(i = 0 ; i < f_cnf.size(); i++){	
	for( int j=0; j<f_cnf[i].size(); j++){	    
//	    cout<<f_cnf[i][j] << " ";
	    picosat_add(ps, f_cnf[i][j]);
	}
//	cout<< endl;
	picosat_add(ps,0);
    }
    
    res= picosat_sat(ps,-1);
    if(res == 10) {
	cout<< "sat \n";
//	vStr.clear();
	mapAtom.clear();
	picosat_reset(ps); 
	return 1;
    } else if (res == 20 ){
	cout<< "unsat \n";
    } else { 
	//cout<< "unknown \n";
    }
//    vStr.clear();
    mapAtom.clear();
    picosat_reset(ps);   
    return 0;
}
