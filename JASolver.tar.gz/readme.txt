
./ja.sh -f <filename> -r <rule> [-a -d -i <formula>]

-f <filename> : input file
-r <rule> : for choosing calculate rule (msa, mcsa, ra, mwa, mnac)
-a : to output all winners 
-d : to only output the default theory
-i <formula> : to test whether formula is in all winners 

If you want to test computing time, please use time command.

If you want to use JASolver, you need to complier the source files of dl2asp and ja to get the program, 
then put them in the same dirctory and use the command to call ja.sh.

create in 2015/04.




