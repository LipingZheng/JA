#!/bin/bash

#: Description: to calculate majority-preserving judgment aggregation rules


## Default values
file_=
filename=
rule=
formula=
dl=
all=

## List of options the program will accept;
optstring=f:r:i:da

while getopts $optstring opt
do
   case $opt in
      f) file_=$OPTARG;;
      r) rule=$OPTARG;;
      i) formula=$OPTARG;;
      d) dl="-d";;
      a) all="-all";;
      *) exit 1;;
   esac
done

## remove options from the command line
## $OPTIND points to the next, unparsed argument
shift "$(( $OPTIND -1 ))"

if [[ $file_ == *\/* ]]
then
   filename=${file_##*/}
   file_dir=${file_%/*}\/
else
   filename=$file_
   file_dir=
fi

## related variables 
tfile="$filename"_"$rule".dl
trule="-$rule"
tdlfile=result_"$tfile"
rfile=result_"$filename"_"$rule"

## check whether a filename was entered
if [ -n "$filename" ]
then
    printf "Source file: %s\n" "$filename"
else
    printf "error: filename is required\n" 
    exit 1
fi

## check whether a rule was entered
if [ -n "$rule" ]
then 
## check whether rule is valid; 
    case "$rule" in
    msa)  printf "Rule: %s\n" "$rule";;
    mcsa) printf "Rule: %s\n" "$rule";;
    mwa)  printf "Rule: %s\n" "$rule";;
    ra)   printf "Rule: %s\n" "$rule";;
    mnac) printf "Rule: %s\n" "$rule";;
    *) printf "error: invaild rule %s \n" "$rule" 
       exit 1 ;;
   esac

else
    printf "error: rule is required\n" 
    exit 1
fi


## call ja

if [ -n "$formula" ]
then
    printf "Test formula: %s\n" "$formula"
    case $rule in
    msa) ./ja "$file_dir$filename" "$trule" "-inw" "$formula";;
    *) ./ja "$file_dir$filename" "$trule" ;;
    esac
else
    ./ja "$file_dir$filename" "$trule" 
fi


## if -d is entered, exit
 if [ -n "$dl" ]
 then 
   exit 0
 fi


## call dl2asp 
case $rule in 
 msa)  
    if [ -n "$all" ]
    then
        ./dl2asp $all "$file_dir$tfile"  > "$tdlfile"
    else
        ./dl2asp "$file_dir$tfile" > "$tdlfile" 
    fi 
    ;;
  *) 
    if [ -n "$all" ]
    then 
         ./dl2asp -max $all "$file_dir$tfile" >  "$tdlfile"
    else
         ./dl2asp -max  "$file_dir$tfile" >  "$tdlfile"
    fi
    ;;
esac

## to get the final result file 
grep ":\|_ID" "$tdlfile" | sed 's/_ID//g' > "$rfile"


printf "\nResult:\n"

## if -i is entered 
if [ -n "$formula" ]
then
case $rule in
   msa)
        if [ -n "`grep "Model" $rfile`" ]
       then
           printf "%s is not in all winners " "$formula"
       else
         printf "%s is in all winners " "$formula"
       fi
        ;;
    *) 
       ## to get cost1;
       cost1=`grep "\[cost" $rfile`
       printf "cost1 %s\n" "$cost1"
       cost1=${cost1#*[0-9]}
       cost1=${cost1%\]*}

        printf "cost1 %d\n" "$cost1"

       ./ja "$file_dir$filename" "$trule" "-inw" "$formula"    
       ./dl2asp -max  "$file_dir$tfile" >  "$tdlfile"
      
       ## to get cost2;
       cost2=`grep "\[cost" $rfile`
       printf "cost2 %s\n" "$cost2"

       cost2=${cost2#*[0-9]}
       cost2=${cost1%\]*}

       printf "cost2 %d\n" "$cost2"

       if [ "$cost1" == "$cost2" ]
       then 
           printf "%s is not in all winners " "$formula"
       else
           printf "%s is in all winners " "$formula"
       fi
      ;;
esac
else
    grep '^[^time\|def\|asp]' "$rfile"
fi


## remove the temp result file
if [ -f "$tdlfile" ]
then 
   rm "$tdlfile"
fi


## remove the file of default theory if -d is not entered
if [ -f "$file_dir$tfile" ]
then 
   rm "$file_dir$tfile"
fi

## remove result file
if [ -f "$rfile" ]
then 
   rm "$rfile"
fi




